package com.example.motivationquote.interfaces;

public interface UserCardClick {
        void getCardClick(int position,String clicktype);
}
